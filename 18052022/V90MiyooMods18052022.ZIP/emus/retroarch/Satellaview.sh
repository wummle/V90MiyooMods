#!/bin/sh

/mnt/emus/retroarch/retroarch -v -L /mnt/.retroarch/cores/snes9x2005_libretro.so --config /mnt/.retroarch/retroarch.cfg "$1"
