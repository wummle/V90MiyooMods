#!/bin/sh

/mnt/emus/retroarch/retroarch -v -L /mnt/.retroarch/cores/cap32_libretro.so --config /mnt/.retroarch/config/retroarchGX4000.cfg "$1"
