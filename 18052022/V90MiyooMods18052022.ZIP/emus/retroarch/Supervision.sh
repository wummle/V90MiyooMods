#!/bin/sh

/mnt/emus/retroarch/retroarch -v -L /mnt/.retroarch/cores/potator_libretro.so --config /mnt/.retroarch/retroarch.cfg "$1"
