#!/bin/sh

/mnt/emus/retroarch/retroarch -v -L /mnt/.retroarch/cores/freechaf_libretro.so --config /mnt/.retroarch/retroarch.cfg "$1"
