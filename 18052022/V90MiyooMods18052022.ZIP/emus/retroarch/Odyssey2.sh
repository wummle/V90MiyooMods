#!/bin/sh

/mnt/emus/retroarch/retroarch -v -L /mnt/.retroarch/cores/o2em_libretro.so --config /mnt/.retroarch/retroarch.cfg "$1"
